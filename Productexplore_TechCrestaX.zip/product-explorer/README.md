# Product Explorer

A responsive product catalogue built with React, TypeScript, Vite, and CSS.

## Requirements

- Node.js 20.19+ or 22.12+ recommended
- npm
- Internet connection for installing dependencies and loading remote product images/fonts

## Run locally

1. Extract the `product-explorer.zip` file.
2. Open the extracted `product-explorer` folder in VS Code.
3. Open the VS Code terminal (**Terminal → New Terminal**).
4. Run:

   ```bash
   npm install
   npm run dev
   ```

5. Open the local URL printed by Vite (usually `http://localhost:5173`).

## Create a production build

```bash
npm run build
npm run preview
```

## Features

- Product cards with image, name, price, category, and description
- Search products by name (case-insensitive)
- Filter by category
- Sort by featured order, price low-to-high, price high-to-low, or name
- Result count and empty state with a clear-filters action
- Responsive layouts for desktop, tablet, and mobile
- Reusable typed components and React hooks

Product photos and Google Fonts are loaded from external URLs, so an internet connection is needed for those assets.