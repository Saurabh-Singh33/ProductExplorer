import { ArrowUpRight } from "lucide-react";
import type { Product } from "../types/Product";

interface ProductCardProps {
  product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
  return (
    <article className="product-card">
      <div className="product-image-wrap">
        <img
          className="product-image"
          src={product.image}
          alt={product.name}
          loading="lazy"
          onError={(event) => {
            event.currentTarget.src =
              "https://placehold.co/600x450/f0efff/292c67?text=Product";
          }}
        />
        <span className="image-category">{product.category}</span>
      </div>
      <div className="product-info">
        <div className="product-title-row">
          <h3>{product.name}</h3>
          <ArrowUpRight aria-hidden="true" size={18} className="card-arrow" />
        </div>
        <p className="product-description">{product.description}</p>
        <div className="product-bottom">
          <p className="product-price">₹{product.price.toLocaleString("en-IN")}</p>
          <span className="price-caption">Inclusive of all taxes</span>
        </div>
      </div>
    </article>
  );
}