import { SearchX } from "lucide-react";
import type { Product } from "../types/Product";
import ProductCard from "./ProductCard";

interface ProductListProps {
  products: Product[];
  onReset: () => void;
}

export default function ProductList({ products, onReset }: ProductListProps) {
  if (products.length === 0) {
    return (
      <div className="empty-state">
        <span className="empty-icon"><SearchX size={27} /></span>
        <h2>No products found</h2>
        <p>We couldn’t find a match. Try another name or change your filters.</p>
        <button className="button button-primary" onClick={onReset}>
          Clear all filters
        </button>
      </div>
    );
  }

  return (
    <div className="product-grid">
      {products.map((product) => (
        <ProductCard key={product.id} product={product} />
      ))}
    </div>
  );
}