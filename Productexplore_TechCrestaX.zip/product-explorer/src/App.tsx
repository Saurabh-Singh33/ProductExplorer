import { useMemo, useState } from "react";
import { Search, SlidersHorizontal, Sparkles } from "lucide-react";
import { products } from "./data/products";
import ProductList from "./components/ProductList";

type SortOption = "featured" | "price-low" | "price-high" | "name";

export default function App() {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All");
  const [sort, setSort] = useState<SortOption>("featured");

  const categories = useMemo(
    () => ["All", ...Array.from(new Set(products.map((product) => product.category)))],
    [],
  );

  const filteredProducts = useMemo(() => {
    const query = search.trim().toLowerCase();

    const result = products.filter((product) => {
      const matchesName = product.name.toLowerCase().includes(query);
      const matchesCategory = category === "All" || product.category === category;
      return matchesName && matchesCategory;
    });

    switch (sort) {
      case "price-low":
        return [...result].sort((a, b) => a.price - b.price);
      case "price-high":
        return [...result].sort((a, b) => b.price - a.price);
      case "name":
        return [...result].sort((a, b) => a.name.localeCompare(b.name));
      default:
        return result;
    }
  }, [search, category, sort]);

  const resetFilters = () => {
    setSearch("");
    setCategory("All");
    setSort("featured");
  };

  return (
    <main>
      <nav className="navbar">
        <a className="brand" href="#" aria-label="Product Explorer home">
          <span className="brand-mark"><Sparkles size={19} /></span>
          <span>find<span className="brand-accent">ly.</span></span>
        </a>
        <span className="nav-note">A little something for everyone</span>
        <span className="nav-pill"><span className="status-dot" /> Curated picks</span>
      </nav>

      <section className="hero">
        <div className="hero-content">
          <p className="eyebrow"><span className="eyebrow-line" /> THE SMARTER WAY TO SHOP</p>
          <h1>Good finds.<br /><span>Better choices.</span></h1>
          <p className="hero-copy">
            Explore everyday essentials and little upgrades, all in one place.
            Search, filter, and find your next favourite.
          </p>
          <a className="hero-link" href="#products">Explore the collection <span>↓</span></a>
        </div>
        <div className="hero-art" aria-hidden="true">
          <div className="art-orbit orbit-one" />
          <div className="art-orbit orbit-two" />
          <div className="art-circle">
            <Sparkles size={42} strokeWidth={1.3} />
          </div>
          <span className="floating-tag tag-top">made for you ✳</span>
          <span className="floating-tag tag-bottom">little things, big joy</span>
          <span className="art-star star-one">✳</span>
          <span className="art-star star-two">✦</span>
        </div>
      </section>

      <section className="explorer-section" id="products">
        <div className="section-heading">
          <div>
            <p className="section-kicker">YOUR NEXT GREAT FIND</p>
            <h2>Explore products<span>.</span></h2>
          </div>
          <p className="result-count"><strong>{filteredProducts.length}</strong> {filteredProducts.length === 1 ? "item" : "items"} to explore</p>
        </div>

        <div className="toolbar">
          <label className="search-box">
            <Search size={19} aria-hidden="true" />
            <input
              type="search"
              placeholder="Search products by name..."
              aria-label="Search products by name"
              value={search}
              onChange={(event) => setSearch(event.target.value)}
            />
            {search && <button className="clear-search" onClick={() => setSearch("")} aria-label="Clear search">×</button>}
          </label>

          <div className="filter-control">
            <SlidersHorizontal size={17} aria-hidden="true" />
            <label className="sr-only" htmlFor="category">Category</label>
            <select id="category" value={category} onChange={(event) => setCategory(event.target.value)}>
              {categories.map((item) => (
                <option key={item} value={item}>{item === "All" ? "All categories" : item}</option>
              ))}
            </select>
          </div>

          <div className="sort-control">
            <label className="sr-only" htmlFor="sort">Sort products</label>
            <select id="sort" value={sort} onChange={(event) => setSort(event.target.value as SortOption)}>
              <option value="featured">Sort: Featured</option>
              <option value="price-low">Price: Low to high</option>
              <option value="price-high">Price: High to low</option>
              <option value="name">Name: A to Z</option>
            </select>
          </div>

          {(search || category !== "All" || sort !== "featured") && (
            <button className="reset-button" onClick={resetFilters}>Reset</button>
          )}
        </div>

        <div className="active-filters" aria-live="polite">
          {category !== "All" && <button onClick={() => setCategory("All")} className="filter-chip">{category} <span>×</span></button>}
          {search && <button onClick={() => setSearch("")} className="filter-chip">“{search}” <span>×</span></button>}
        </div>

        <ProductList products={filteredProducts} onReset={resetFilters} />
      </section>

      <footer className="footer">
        <a className="brand footer-brand" href="#"><span className="brand-mark"><Sparkles size={16} /></span><span>find<span className="brand-accent">ly.</span></span></a>
        <p>Thoughtful finds for everyday life.</p>
        <span>Built with React + TypeScript</span>
      </footer>
    </main>
  );
}